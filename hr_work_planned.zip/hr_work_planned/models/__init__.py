# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr_work_planned
from . import hr_employee
